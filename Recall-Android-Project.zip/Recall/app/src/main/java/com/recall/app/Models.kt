package com.recall.app

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class Side(val text: String = "", val photo: String? = null) {
    fun json() = JSONObject().put("text", text).put("photo", photo)
    companion object { fun from(j: JSONObject) = Side(j.optString("text"), j.optString("photo").takeIf { it.isNotBlank() && it != "null" }) }
}
data class FlashCard(
    val id: String = UUID.randomUUID().toString(),
    val question: Side,
    val answer: Side,
    val dueAt: Long = 0L,
    val interval: Int = 0,
    val reps: Int = 0
) {
    fun json() = JSONObject().put("id", id).put("question", question.json()).put("answer", answer.json())
        .put("dueAt", dueAt).put("interval", interval).put("reps", reps)
    companion object { fun from(j: JSONObject) = FlashCard(j.getString("id"), Side.from(j.getJSONObject("question")), Side.from(j.getJSONObject("answer")), j.optLong("dueAt"), j.optInt("interval"), j.optInt("reps")) }
}
data class Deck(val id: String = UUID.randomUUID().toString(), val name: String, val cards: MutableList<FlashCard> = mutableListOf()) {
    fun json() = JSONObject().put("id", id).put("name", name).put("cards", JSONArray().also { a -> cards.forEach { a.put(it.json()) } })
    companion object { fun from(j: JSONObject) = Deck(j.getString("id"), j.getString("name"), mutableListOf<FlashCard>().also { out -> val a=j.optJSONArray("cards") ?: JSONArray(); for(i in 0 until a.length()) out.add(FlashCard.from(a.getJSONObject(i))) }) }
}
data class Chapter(val id: String = UUID.randomUUID().toString(), val name: String, val decks: MutableList<Deck> = mutableListOf()) {
    fun json() = JSONObject().put("id", id).put("name", name).put("decks", JSONArray().also { a -> decks.forEach { a.put(it.json()) } })
    companion object { fun from(j: JSONObject) = Chapter(j.getString("id"), j.getString("name"), mutableListOf<Deck>().also { out -> val a=j.optJSONArray("decks") ?: JSONArray(); for(i in 0 until a.length()) out.add(Deck.from(a.getJSONObject(i))) }) }
}
data class Folder(val id: String = UUID.randomUUID().toString(), val name: String, val chapters: MutableList<Chapter> = mutableListOf()) {
    fun json() = JSONObject().put("id", id).put("name", name).put("chapters", JSONArray().also { a -> chapters.forEach { a.put(it.json()) } })
    companion object { fun from(j: JSONObject) = Folder(j.getString("id"), j.getString("name"), mutableListOf<Chapter>().also { out -> val a=j.optJSONArray("chapters") ?: JSONArray(); for(i in 0 until a.length()) out.add(Chapter.from(a.getJSONObject(i))) }) }
}
