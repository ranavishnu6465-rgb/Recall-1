package com.recall.app

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class AddCardTileService: TileService() {
    override fun onClick(){super.onClick(); startForegroundService(Intent(this,RecallOverlayService::class.java).setAction("POPUP")); qsTile?.state=Tile.STATE_ACTIVE; qsTile?.updateTile()}
}
